/**
 * $Id: TsrRecord.cs 9 2006-09-21 22:13:20Z outburst $
 * 
 * STDFSharp
 *
 * File: TsrRecord.cs
 * Description:
 * 
 * Copyright (C) 2006 Outburst <outburst@users.sourceforge.net>
 *  
 * This library is free software; you can redistribute it and/or 
 * modify it under the terms of the GNU Lesser General Public License 
 * as published by the Free Software Foundation; either version 2.1 
 * of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful, 
 * but WITHOUT ANY WARRANTY; without even the implied warranty of 
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this library; if not, write to the Free Software Foundation, 
 * Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */

using System;
using KA.StdfSharp.Record.Field;
using Char=KA.StdfSharp.Record.Field.Char;
using String=KA.StdfSharp.Record.Field.String;

namespace KA.StdfSharp.Record
{
    /// <summary>
    /// Represents the TSR record of STDF.
    /// </summary>
    [StdfRecord(10, 30)]
    public class TsrRecord : StdfRecord
    {
        private IField<byte>        headNumber              = new UByte(); // HEAD_NUM U*1 Test head number
        private IField<byte>        siteNumber              = new UByte(); // SITE_NUM U*1 Test site number
        private IField<char>        testType                = new Char(); // TEST_TYP C*1 Test type
        private IField<uint>        testNumber              = new UInt(); // TEST_NUM U*4 Test number
        private IField<uint>        executionCount          = new UInt(); // EXEC_CNT U*4 Number of test executions
        private IField<uint>        failCount               = new UInt(); // FAIL_CNT U*4 Number of test failures
        private IField<uint>        alarmCount              = new UInt(); // ALRM_CNT U*4 Number of alarmed tests
        private IField<string>      testName                = new String(); // TEST_NAM C*n Test name
        private IField<string>      sequencerName           = new String(); // SEQ_NAME C*n Sequencer (program segment/flow) name 
        private IField<string>      testLabel               = new String(); // TEST_LBL C*n Test label or text
        private IBitField           optionalDataFlag        = new OptionalDataFlagField(); // OPT_FLAG B*1 Optional data flag 
        private IField<DateTime>    executionTime           = new Date(); // TEST_TIM R*4 Average test execution time in seconds
        private IField<float>       lowestResultValue       = new Float(); // TEST_MIN R*4 Lowest test result value
        private IField<float>       highestResultValue      = new Float(); // TEST_MAX R*4 Highest test result value
        private IField<float>       resultValuesSum         = new Float(); // TST_SUMS R*4 Sumof test result values
        private IField<float>       resultValuesSquareSum   = new Float(); // TST_SQRS R*4 Sum of squares of test result values

        public TsrRecord()
        {
            AddField("HEAD_NUM", headNumber);
            AddField("SITE_NUM", siteNumber);
            AddField("TEST_TYP", testType);
            AddField("TEST_NUM", testNumber);
            AddField("EXEC_CNT", executionCount);
            AddField("FAIL_CNT", failCount);
            AddField("ALRM_CNT", alarmCount);
            AddField("TEST_NAM", testName);
            AddField("SEQ_NAME", sequencerName);
            AddField("TEST_LBL", testLabel);
            AddField("OPT_FLAG", optionalDataFlag);
            AddField("TEST_TIM", executionTime);
            AddField("TEST_MIN", lowestResultValue);
            AddField("TEST_MAX", highestResultValue);
            AddField("TST_SUMS", resultValuesSum);
            AddField("TST_SQRS", resultValuesSquareSum);
        }
        
        public IField<byte> HeadNumber
        {
            get { return headNumber; }
        }

        public IField<byte> SiteNumber
        {
            get { return siteNumber; }
        }

        public IField<char> TestType
        {
            get { return testType; }
        }

        public IField<uint> TestNumber
        {
            get { return testNumber; }
        }

        public IField<uint> ExecutionCount
        {
            get { return executionCount; }
        }

        public IField<uint> FailCount
        {
            get { return failCount; }
        }

        public IField<uint> AlarmCount
        {
            get { return alarmCount; }
        }

        public IField<string> TestName
        {
            get { return testName; }
        }

        public IField<string> SequencerName
        {
            get { return sequencerName; }
        }

        public IField<string> TestLabel
        {
            get { return testLabel; }
        }

        public IField<DateTime> ExecutionTime
        {
            get { return executionTime; }
        }

        public IField<float> LowestResultValue
        {
            get { return lowestResultValue; }
        }

        public IField<float> HighestResultValue
        {
            get { return highestResultValue; }
        }

        public IField<float> ResultValuesSum
        {
            get { return resultValuesSum; }
        }

        public IField<float> ResultValuesSquareSum
        {
            get { return resultValuesSquareSum; }
        }

        private class OptionalDataFlagField : BitEncoded<TsrRecord>
        {
            /// <summary>
            /// Validate the field's value.
            /// </summary>
            /// <remarks>Each subclasses should override to validate field's value.</remarks>
            protected override void DoValidate()
            {
                if (!EvaluateAnd((byte)OptionalDataFlagBit.LowestResult))
                    ParentRecord.LowestResultValue.Valid = false;
                if (!EvaluateAnd((byte)OptionalDataFlagBit.HighestResult))
                    ParentRecord.HighestResultValue.Valid = false;
                if (!EvaluateAnd((byte)OptionalDataFlagBit.ExecutionTime))
                    ParentRecord.ExecutionTime.Valid = false;
                if (!EvaluateAnd((byte)OptionalDataFlagBit.Sum))
                    ParentRecord.ResultValuesSum.Valid = false;
                if (!EvaluateAnd((byte)OptionalDataFlagBit.SquareSum))
                    ParentRecord.ResultValuesSquareSum.Valid = false;
            }
        }

        [Flags]
        private enum OptionalDataFlagBit : byte
        {
            Unknown = 0x00,
            LowestResult = 0x01, // bit 0
            HighestResult = 0x02, // bit 1
            ExecutionTime = 0x04, // bit 2
            Reserved1 = 0x08, // bit 3
            Sum = 0x10, // bit 4
            SquareSum = 0x20, // bit 5
            Reserved2 = 0x40, // bit 6
            Reserved3 = 0x80, // bit 7
            All = LowestResult | HighestResult | ExecutionTime | Reserved1 | Sum | SquareSum | Reserved2 | Reserved3
        }

    }
}