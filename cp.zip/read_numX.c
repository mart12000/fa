#include <string.h>
#include <stdio.h>
#include <stdlib.h>

FILE *tskmap, *input, *output;
char ch;
int i,j,k,in_count=0,where=0;
char charbuf[100];
unsigned int binvalue;
int xpower[4]={1,256,65536,16777216};
unsigned int bitmask[8]={1,2,4,8,16,32,64,128};
unsigned int bit[8];
unsigned int curx,cury,xpolar,ypolar,result,curbin;
int signedcurx,signedcury;
unsigned int xpolarmask=8, ypolarmask=4;
char polar[2]={' ','-'};
char wafer_id[21];
int wafer_id_len=0;
char *test_result[4]={"Notest","Pass","Fail1","Fail2"};
char *comment[5]={"Original","Substituted","NotSubstituted","Original1","Original2"};
unsigned char byte[6],passbyte=64,failbyte=128,xyneg=76,xneg=72,yneg=68,xypos=64,blank=0;

int found,x[30000],y[30000],bin[30000],binpf[3000],pf[30000],binsum[3000];
char *spf[2]={"Fail","Pass"};
unsigned int sub_count=0;
unsigned int pass_dice=0, pass_byte[2];
unsigned int fail_dice=0, fail_byte[2];
unsigned int total_dice=0, total_byte[2];
unsigned char maskX=63;

char line[3000];

long curpos;

int read_map(char name[25], int size, char type)
{
        int x,y,z;
        switch (type) {
        case 'C': 
        for(x=0;x<size;x++) {
                charbuf[x] = fgetc(tskmap);
                if(output) {
                   if(!strstr(name,"Wafer ID"))
                        fputc(charbuf[x],output);
                }
        }
        charbuf[x] = '\0';
        if(output && strstr(name,"Wafer ID")) {
                for(x=0;x<21;x++) fputc(wafer_id[x],output);
        }
        printf("%+25s : %s<CR>\n",name,charbuf);
        break;
        case 'B': 
        binvalue=0;
        for(x=0,y=size-1;x<size,y>=0;x++,y--) {
                ch = fgetc(tskmap);
                if(output) {
                if(strstr(name,"Total tested dice")){
                ch = total_byte[x];
                /* printf("total_byte[%d] = %d\n",x,total_byte[x]); */
                }
                if(strstr(name,"Total pass dice")){
                ch = pass_byte[x];
                /* printf("pass_byte[%d] = %d\n",x,pass_byte[x]); */
                }
                if(strstr(name,"Total fail dice")){
                ch = fail_byte[x];
                /* printf("fail_byte[%d] = %d\n",x,fail_byte[x]); */
                }}

                byte[0] = ch;
                binvalue+=xpower[y]*byte[0];
                if(output) fputc(ch,output);
        }
        printf("%+25s : %d<CR>\n",name,binvalue);
        break;
        default:
        printf("Error! Type %c not found!",type);
        break;
        }

}

main(argc,argv)
int argc; char *argv[];
{

   for(i=0;i<3000;i++) {binsum[i] = 0; binpf[i] = -1;}
   for(i=0;i<30000;i++) { pf[i] = 0;}

   if(!(tskmap = fopen(argv[1], "r"))) exit(3);
   if(argc>3) {
                if(!(output = fopen(argv[3], "w"))) exit(5);
                strcpy(wafer_id,argv[3]);
                wafer_id_len = strlen(wafer_id);
                for(i=wafer_id_len;i<21;i++) wafer_id[i] = ' ';
   }

   if(argc>5) {
        pass_dice=atoi(argv[4]);
        fail_dice=atoi(argv[5]);
        total_dice=pass_dice+fail_dice;
        pass_byte[1]=pass_dice % 256;
        pass_byte[0]=(pass_dice - pass_byte[1]) / 256;
        fail_byte[1]=fail_dice % 256;
        fail_byte[0]=(fail_dice - fail_byte[1]) / 256;
        total_byte[1]=total_dice % 256;
        total_byte[0]=(total_dice - total_byte[1]) / 256;
        /* printf("argv %d %d %d %d %d %d %d %d %d\n",pass_dice,fail_dice,total_dice,pass_byte[1],pass_byte[0],fail_byte[1],fail_byte[0],total_byte[1],total_byte[0]); */
   }

   if(argc>2) {
   in_count=0;
   if(!(input = fopen(argv[2], "r"))) exit(4);
   fseek(input, 0, SEEK_SET);
   while ((fgets(line,sizeof(line) -1,input)) != NULL) {
   if (sscanf(line,"%d %d %d %d",&x[in_count],&y[in_count],&bin[in_count],&pf[in_count])!=4)
        fprintf(stderr, "Error pattern %s. line skipped.\n",line);
   else {
        binpf[bin[in_count]] = pf[in_count];
        /* printf("in_count = %d x %d y %d bin %d pf %d\n",in_count,x[in_count],y[in_count],bin[in_count],binpf[bin[in_count]]);  */
        in_count++;  }
   }
   printf("in_count = %d x %d y %d\n",in_count,x[in_count-1],y[in_count-1]);
   fclose(input);
   }

   fseek(tskmap, 0, SEEK_SET);

   /* Wafer Testing Setup Data */
   read_map("Operator Name",20,'C');
   read_map("Device Name",16,'C');
   read_map("Wafer Size",2,'B');
   read_map("Machine No.",2,'B');
   read_map("Index Size_X",4,'B');
   read_map("Index Size_Y",4,'B');
   read_map("Flat Direction",2,'B');
   read_map("Final Editing Mach",1,'B');
   read_map("Reserved",1,'B');

   /* Map data area row & line size */
   read_map("Row size",2,'B');
   read_map("Line size",2,'B');
   read_map("Reserved",4,'B');

   /* Wafer Specific Data */
   read_map("Wafer ID",21,'C');
   read_map("Measured times",1,'B');
   read_map("Lot No.",18,'C');
   read_map("Cassette No.",2,'B');
   read_map("Slot No.",2,'B');

   /* Wafer Probing Coordinate System Data */
   read_map("X axis inc dir",1,'B');
   read_map("Y axis inc dir",1,'B');
   read_map("Reff die setting",1,'B');
   read_map("Reserved",1,'B');
   read_map("Target die pos X",4,'B');
   read_map("Target die pos Y",4,'B');
   read_map("Reff die coor X",2,'B');
   read_map("Reff die coor Y",2,'B');
   read_map("Probing start pos",1,'B');
   read_map("Probing dir",1,'B');
   read_map("Reserved",2,'B');
   read_map("Distance X to center",4,'B');
   read_map("Distance Y to center",4,'B');
   read_map("Coor X of center die",4,'B');
   read_map("Coor Y of center die",4,'B');
   read_map("Reserved",4,'B');
   read_map("Reserved",4,'B');

   /* Wafer Testing Start Time Data */
   read_map("Year",2,'C');
   read_map("Month",2,'C');
   read_map("Day",2,'C');
   read_map("Hour",2,'C');
   read_map("Minute",2,'C');
   read_map("Reserved",2,'B');

   /* Wafer Testing End Time Data */
   read_map("Year",2,'C');
   read_map("Month",2,'C');
   read_map("Day",2,'C');
   read_map("Hour",2,'C');
   read_map("Minute",2,'C');
   read_map("Reserved",2,'B');

   /* Wafer Loading Time Data */
   read_map("Year",2,'C');
   read_map("Month",2,'C');
   read_map("Day",2,'C');
   read_map("Hour",2,'C');
   read_map("Minute",2,'C');
   read_map("Reserved",2,'B');

   /* Wafer Unloading Time Data */
   read_map("Year",2,'C');
   read_map("Month",2,'C');
   read_map("Day",2,'C');
   read_map("Hour",2,'C');
   read_map("Minute",2,'C');
   read_map("Reserved",2,'B');

   read_map("Reserved",4,'B');
   read_map("Reserved",4,'B');
   read_map("Reserved",4,'B');

   /* Testing Result */
   read_map("Testing end status",1,'B');
   read_map("Reserved",1,'B');
   read_map("Total tested dice",2,'B');
   read_map("Total pass dice",2,'B');
   read_map("Total fail dice",2,'B');

   /* Measurement Die Information Address */
   read_map("6-byte address range",4,'B');
   read_map("Num of line cat data",4,'B');
   read_map("Line cat address",4,'B');
   read_map("Reserved",4,'B');
   read_map("Reserved",4,'B');
 
   byte[0] = fgetc(tskmap); printf("%5d ",byte[0]);
   do
   {
      for(j=7;j>=0;j--){bit[j]=byte[0] & bitmask[j]; bit[j]=bit[j] >> j ; printf("%d",bit[j]); }
      printf(" ");
      result = byte[0] >> 6;
      byte[1] = fgetc(tskmap); 
      for(j=7;j>=0;j--){bit[j]=byte[1] & bitmask[j]; bit[j]=bit[j] >> j ; printf("%d",bit[j]); }
      printf("%5d ",byte[1]);
      curx = byte[1];
      printf(" Byte 2\n");
      byte[2] = fgetc(tskmap); printf("%5d ",byte[2]);
      for(j=7;j>=0;j--){bit[j]=byte[2] & bitmask[j]; bit[j]=bit[j] >> j ; printf("%d",bit[j]); }
      printf(" ");
      xpolar = byte[2] & xpolarmask; xpolar = xpolar >> 3;
      ypolar = byte[2] & ypolarmask; ypolar = ypolar >> 2;
      byte[3] = fgetc(tskmap); 
      for(j=7;j>=0;j--){bit[j]=byte[3] & bitmask[j]; bit[j]=bit[j] >> j ; printf("%d",bit[j]); }
      printf("%5d ",byte[3] );
      cury = byte[3]; 
      printf(" Byte 4\n");
      byte[4] = fgetc(tskmap); printf("%5d ",byte[4]);
      for(j=7;j>=0;j--){bit[j]=byte[4] & bitmask[j]; bit[j]=bit[j] >> j ; printf("%d",bit[j]); }
      printf(" ");
      byte[5] = fgetc(tskmap); 
      for(j=7;j>=0;j--){bit[j]=byte[5] & bitmask[j]; bit[j]=bit[j] >> j ; printf("%d",bit[j]); }
      curbin=byte[5];
      printf("%5d ",byte[5]);
      printf(" Byte 6\n");

      if(result) binsum[curbin]++;

      if(xpolar) signedcurx=curx*-1;
      else signedcurx=curx;
      if(ypolar) signedcury=cury*-1;
      else signedcury=cury;
              where=0;
      if(binpf[curbin] == -1) {if(result == 1) binpf[curbin] = 1; else binpf[curbin] = 0; }
      /* printf("\nx %d y %d result %d bin %d binpf %d\n",signedcurx,signedcury,result,curbin,binpf[curbin]); */

      /* if(curbin && output) { */
      if(output && result) {
         found = 0;
         for(j=in_count-1;j>=0;j--)
              if(signedcurx==x[j]&&signedcury==y[j]) {found=1;break;}
         if(found) {
            where=1;
            sub_count++;
            if(pf[j]==1) {
      /* printf("\nj %d PUT PASS BYTE pf %d x %d y %d result %d bin %d pf %d\n",j,pf[j],signedcurx,signedcury,result,curbin,binpf[bin[j]]); */
fputc(passbyte,output);
            } else {
      /* printf("\nj %d PUT FAIL BYTE pf %d x %d y %d result %d bin %d pf %d\n",j,pf[j],signedcurx,signedcury,result,curbin,pf[bin[j]]); */
         fputc(failbyte,output);
}
            fputc(curx,output);
            if(xpolar && ypolar) fputc(xyneg,output);
            if(xpolar && !ypolar) fputc(xneg,output);
            if(!xpolar && ypolar) fputc(yneg,output);
            if(!xpolar && !ypolar) fputc(xypos,output);
            fputc(cury,output);
            fputc(blank,output); fputc(bin[j],output);
            if(result) {binsum[curbin]--;
                        binsum[bin[j]]++;}
         } else {
            where=2;
            byte[0] = byte[0] & maskX;
            byte[5] = 64;
            for(j=0;j<6;j++) fputc(byte[j],output);
         }
      } else {
         where=3;
         if(output) for(j=0;j<6;j++) {
                where=4;
                fputc(byte[j],output);
         }
      }
      printf("\nx %d y %d result %s bin %d %s\n\n",signedcurx,signedcury,test_result[result],curbin,comment[where]);
      byte[0] = ch = fgetc(tskmap); 
      if(ch != EOF) printf("%5d ",byte[0]);
      i++;
   } while (ch != EOF);

   if(argc>3) {
   fclose(output);
   printf("\n\n");
   printf("     Substituted Dice = %3d\n",sub_count);
   }
   
   fclose(tskmap);
   printf("\n\n");
   total_dice=pass_dice=fail_dice=0;
   for(i=0;i<1000;i++)if(binsum[i]>0) {
           total_dice += binsum[i];
           if(binpf[i]==1) pass_dice += binsum[i];
           else            fail_dice += binsum[i];
           printf("     SUMM Bin %3d = %3d (%s)\n",i,binsum[i],spf[binpf[i]]);}

           printf("     SUMM Total Dice = %3d\n",total_dice);
           printf("     SUMM Total Pass Dice = %3d\n",pass_dice);
           printf("     SUMM Total Fail Dice = %3d\n",fail_dice);
   if(in_count == sub_count) exit(0);
   else {
        printf("\n      SUMM in_count %d sub_count %d\n",in_count,sub_count);
        if(in_count < sub_count) exit(1);
        if(in_count > sub_count) exit(2);
   }
}
