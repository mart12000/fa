#!/bin/sh
#############################################################################
## Script Name 	: Pre_AG3K_Prober.sh
## Purpose 	: This script is to FTP over the External Data Header 
##		  and Prober File from test server and rename it to a unix name 
##		  and preprocessed it to a format ready to load into Data Power
## Author	: SSMC IT and TRW Inc.
## Date 	: 22 Oct 2001
## Version 	: 01
##
## Update Version 	: 02 
## Update Purposes 	: SR Change the Prober flow to grep the correct version of the ED file
##
## Update Version 	: 03 
## Update Purposes 	: Replace wmap with prober2xml.
##
## Update Version 	: 04 
## Update Purposes 	: Update prober2xml from Version 2.1 to 2.4.
##
## Update Version 	: 05 
## Update Purposes 	: Update prober2xml from Version 2.4 to 2.10.
##
## Update Version	: 06
## Update Purpose	: Send a copy to TYES
##		    
## Update Version	: 07
## Update Purpose	: (20160813) Add routines to dispatch STDF(PINK) files to SEDA server (MSEDA101).
##		    
##############################################################################

DEBUG=1		#(Turn the DEBUG=1 when you want to trace the program error)
DATEPART=`date "+%Y-%m"`

# 20160813
SMSLIST="${HOME}/dp_data/Script/datapower.sms"
dp_sms=`cat $SMSLIST`
DATEPART2=`date "+%Y%m%d_%H%M%S"`

MAILTABLE="${HOME}/dp_data/Script/mailing_table.txt"
MAILLIST=`cat $MAILTABLE | grep DI_GRP | awk -F'=' '{ print $2 }'`
MAILSENDER="${HOME}/dp_data/Script/EDA_mail_sender.txt"
MSENDER=`cat $MAILSENDER`
mydir="/app/idsdb/dp_data/Data_In/SSMC_SR_HP93000_tester"

ED_Header_Dir="/app/idsdb/dp_data/Data_In/SSMC_HP93K_ED_Header"
ED_Header_Temp_Dir="$ED_Header_Dir/AG93K_Temp"
ED_Pro_Dir="$mydir/AG93K_Prober/ED_Processed"
ED_NPro_Dir="$mydir/AG93K_Prober/ED_NotProcessed"
Map_Dir="$mydir/AG93K_Prober/Map"
Prober_Dir="$mydir/AG93K_Prober/Prober"
Prober_Ready_Dir="$mydir/AG93K_Prober/Pro_Processed"
Prober_NReady_Dir="$mydir/AG93K_Prober/Pro_NotProcessed"
Suc_Loc_Prep_Dir="$mydir/AG93K_Prober"
Fail_Loc_Prep_Dir="$mydir/AG93K_Prober/PrepDir/NotProcessed"
Working_Dir="$mydir/AG93K_Prober/PrepDir"
Archive_Dir="/app/idsdb/dp_data/Archive/test_data/SSMC_SR_HP93K_Prober"
# modifed by Nicolas as requested by TE (SR20080715002) 
Tyesout_Dir="/app/idsdb/dp_data/Data_Out/TYES_HP93KPROB/PrepDir/PreProduct"
Log_Dir="${HOME}/dp_data/Log"
Error_Dir="${HOME}/dp_data/Error"
Temp_Dir="${HOME}/dp_data/Temp"

# Modifed by EW (19/11/2004).
WMAP="${HOME}/dp_data/Bin/prober2xml -x ${HOME}/dp_data/Bin/tdf_definitions.xml"

MSGFILE=${HOME}/dp_data/Temp/AG93K_Prober_Error_Files.txt

TEMP1="${HOME}/dp_data/Temp/temp1.txt"
TEMP2="${HOME}/dp_data/Temp/temp2.txt"
TEMP3="${HOME}/dp_data/Temp/temp3.txt"
TEMP4="${HOME}/dp_data/Temp/temp4.txt"
TEMP5="${HOME}/dp_data/Temp/temp5.txt"
TEMP7="${HOME}/dp_data/Temp/temp7.txt"
TEMP8="${HOME}/dp_data/Temp/temp8.txt"
TEMP_OUT="temp_out.txt"
AG93K_Prober_Job="${HOME}/dp_data/Temp/temp6.txt"
FTP_DEL_ED="${HOME}/dp_data/Temp/FTP_DEL_ED.txt"

FTPSRC="sgs1fs03"
FTPUSER="engineer"
FTPPASW="engineer"
FTPDIR1="/server/localinfo/ED_Header/HP93K"
FTPDIR2="/server/AG93K_Prober"

# 20160813
SEDAFTPSRC="mseda101"
SEDAFTPUSER="sedasftp"
SEDAFTPPASSWD="Ieda#ssmc2016"
SEDAFTPDIRSTDF="SEDA_CP_IH_HP_PINK"
SEDAFTPDIREDH="SEDA_CP_IH_HP_EDH"
SEDADIR="${HOME}/dp_data/Data_Out/SEDA/CP_STDF_HP_PINK/"
SEDAEDHDIR="${HOME}/dp_data/Data_Out/SEDA/CP_STDF_HP_EDH/"
SEDAFTPLOG="${Log_Dir}/SEDA_FTPLOG_AG93K_PROBER_STDF.log"
SEDALOGFILE="${Log_Dir}/DP2SEDA_Pre_AG93K_Prober_${DATEPART2}.log"

ErrStrA="No ED File!"
ErrStrB="No matching ED!"
ErrStr="Preprocessing Error: "

########### Checking the same instance of Processes #################

Checking_Processes() {

ps -ef | grep Pre_AG3K_Prober.sh | awk '{print $9}' | sed '/*Pre_AG93K_Prober\.sh/p' > $AG93K_Prober_Job
Have_Job=0

while read PJ
do
	      let "Have_Job = Have_Job + 1"
	      
	      if [ ${DEBUG} = 1 ]; then
	      	printf "Job count : ${Have_Job}\t\t${PJ}"
	      fi
done < $AG93K_Prober_Job

rm $AG93K_Prober_Job

if [ ${Have_Job} -eq 3 ]; then

 	if [ ${DEBUG} = 1 ]; then
 		echo "Have One Pre_AG3K_Prober Process Only!"
 	fi
 	echo "One AG93K_Prober job `date`" >> ${Log_Dir}/HP93K_Prober_Job_${DATEPART}.log

elif [ $Have_Job -gt 3 ]; then

 	if [ ${DEBUG} = 1 ]; then   
   		echo "More than one AG93K_Prober Process"
 	fi
 	echo "More than one AG93K_Prober job `date`" >> ${Log_Dir}/HP93K_Prober_Job_${DATEPART}.log
 	exit
fi

}
########### End Checking the same instance of Processes ##############

######## Cheching the External File is complete file or not ##########
# To check the tail of the External Data Header File
# To prevent ftp over those file are currently open for writing 
######################################################################

Checking_ED_Complete() {

cd ${ED_Header_Temp_Dir}
ls > $TEMP4

if [ -s $TEMP4 ]; then

	while read ED_File
	do 
		if [ ${DEBUG} = 1 ]; then
			echo "Start Checking_ED_Complete Function : ${ED_File}"
		fi
		
		tail ${ED_File} | grep "</ED_EXTERNAL_DATA>" >$TEMP5
		
		if [ -s $TEMP5 ]; then
			if [ ${DEBUG} = 1 ]; then
				echo "${ED_File} is a Complete File!"
			fi
			echo ${ED_File} >> ${FTP_DEL_ED}
		else 
			rm ${ED_File}
		fi			
	
		cd ${ED_Header_Temp_Dir}
	done < $TEMP4
	
	rm $TEMP4 $TEMP5
	
	if [ -f $FTP_DEL_ED ]; then
		while read FILE_NAME
		do
			FTP_OUT="`ftp -i -n ${FTPSRC} <<EOFFTP 
		                user ${FTPUSER} ${FTPPASW}
		                bin
				cd ${FTPDIR1}
		                del ${FILE_NAME}
		                quit
		      	EOFFTP`"
		
			echo "${FILE_NAME} `date`" >> ${Log_Dir}/FTP_ED_HEADER_${DATEPART}.log
			mv ${ED_Header_Temp_Dir}/${FILE_NAME} ${ED_Header_Dir}
		
		done < ${FTP_DEL_ED}
		rm ${FTP_DEL_ED}
	fi
else 
	rm $TEMP4
fi
}
###### End Checking the External File is complete file or not ########

########### FTP External Data Header File to DP ######################

FTP_EDH() {

if [ ${DEBUG} = 1 ]; then
	echo "Start FTP EDH Function"
fi

FTP_OUT="`ftp -i -n ${FTPSRC} <<EOFFTP 
                user ${FTPUSER} ${FTPPASW}
                asc
				cd ${FTPDIR1}
				dir . FTP_ED_HEADER_FILES
				EOFFTP`"

cat FTP_ED_HEADER_FILES | awk '{print $NF}'|sed 1,3d | grep -i xml$ > FTP_ED_HEADER.txt

while read FILE_NAME
do
	FTP_OUT="`ftp -i -n ${FTPSRC} <<EOFFTP 
                user ${FTPUSER} ${FTPPASW}
                bin
				cd ${FTPDIR1}
                get ${FILE_NAME}
                quit
				EOFFTP`"
				
	# 20161116
	# Copy file to SEDA folder.
	if [ $SEDA_SRV_STOP == 0 ]; then
			FILENAME=\"${FILE_NAME}\"
			FTPSTR="`ftp -i -n ${SEDAFTPSRC} <<EOFFTP > ${SEDAFTPLOG}
					user ${SEDAFTPUSER} ${SEDAFTPPASSWD}
					cd ${SEDAFTPDIREDH}
					bin
					put ${FILENAME}
					bye
					EOFFTP`"

		EXITFTP=$?

		if [ $EXITFTP -ne 0 ]; then echo "Pre_AG93K_Prober.sh: $EXITFTP" >> ${SEDALOGFILE}; fi

		if fgrep -i "Not connected" ${SEDAFTPLOG} ;then
			echo "${FILE_NAME}: Failed to transfer!" >> ${SEDALOGFILE}

			if [ -d ${SEDAEDHDIR} ]; then
				cp -p "${FILE_NAME}" ${SEDAEDHDIR}/
			fi

			if [ ${SEDA_FTP_FAIL} == 0 ]; then
				echo "Pre_AG93K_Prober.sh SEDA FTP failure at $(date)" > /tmp/seda_ftp_fail_ag93k_prober_stdf.txt
				mail -s "[SEDA] Pre_AG93K_Prober.sh: FTP Failure at $(date)" $MAILLIST -- -f "${MSENDER}" < /tmp/seda_ftp_fail_ag93k_prober_stdf.txt
				touch seda_job_fail_ag93k_prober_stdf.txt
				mailx -s "Pre_AG93K_Prober.sh SEDA FTP failure at $(date)" $dp_sms < seda_job_fail_ag93k_prober_stdf.txt
				rm seda_job_fail_ag93k_prober_stdf.txt
				SEDA_FTP_FAIL=1
			fi
		else
			echo "${FILE_NAME}: Successfully transfer!" >> ${SEDALOGFILE}
			SEDA_FTP_FAIL=0
		fi
	else
			if [ -d ${SEDAEDHDIR} ]; then
				cp -p "${FILE_NAME}" ${SEDAEDHDIR}/
			fi
	fi

	mv ${FILE_NAME} ${ED_Header_Temp_Dir}

done < FTP_ED_HEADER.txt

rm FTP_ED_HEADER_FILES
rm FTP_ED_HEADER.txt

Checking_ED_Complete	# call the Checking_ED_Complete Function

# 20161116
# Copy failed to send files to SEDA folder.
if [ ${SEDA_FTP_FAIL} == 0 ]; then
	cd ${SEDAEDHDIR}

	ls *xml > FTP_FAILED_ED_HDR.txt

	while read FILE_NAME
	do
		
		if [ $SEDA_SRV_STOP == 0 ]; then
				FILENAME=\"${FILE_NAME}\"
				FTPSTR="`ftp -i -n ${SEDAFTPSRC} <<EOFFTP > ${SEDAFTPLOG}
						user ${SEDAFTPUSER} ${SEDAFTPPASSWD}
						cd ${SEDAFTPDIREDH}
						bin
						put ${FILENAME}
						bye
						EOFFTP`"
	
			EXITFTP=$?
	
			if [ $EXITFTP -ne 0 ]; then echo "Pre_AG93K_Prober.sh: $EXITFTP" >> ${SEDALOGFILE}; fi
	
			if fgrep -i "Not connected" ${SEDAFTPLOG} ;then
				echo "${FILE_NAME}: Failed to transfer!" >> ${SEDALOGFILE}
	
				if [ ${SEDA_FTP_FAIL} == 0 ]; then
					echo "Pre_AG93K_Prober.sh SEDA FTP failure at $(date)" > /tmp/seda_ftp_fail_ag93k_prober_stdf.txt
					mail -s "[SEDA] Pre_AG93K_Prober.sh: FTP Failure at $(date)" $MAILLIST -- -f "${MSENDER}" < /tmp/seda_ftp_fail_ag93k_prober_stdf.txt
					touch seda_job_fail_ag93k_prober_stdf.txt
					mailx -s "Pre_AG93K_Prober.sh SEDA FTP failure at $(date)" $dp_sms < seda_job_fail_ag93k_prober_stdf.txt
					rm seda_job_fail_ag93k_prober_stdf.txt
					SEDA_FTP_FAIL=1
				fi
			else
				echo "${FILE_NAME}: Successfully transfer!" >> ${SEDALOGFILE}
				rm "${FILE_NAME}"
				SEDA_FTP_FAIL=0
			fi
		fi
	done < FTP_FAILED_ED_HDR.txt
	rm FTP_FAILED_ED_HDR.txt
fi


if [ ${DEBUG} = 1 ]; then
	echo "End FTP EDH Function"
fi
}

########## END OF FUNCTION FTP EXTERNAL DATA HEADER FILE #############

########## FTP Prober Output File (XML) to DP ########################

FTP_Prober() {

if [ ${DEBUG} = 1 ]; then
	echo "Start FTP Prober Function"
fi

FTP_OUT="`ftp -i -n ${FTPSRC} <<EOFFTP 
		user ${FTPUSER} ${FTPPASW}
		asc
		cd ${FTPDIR2}
		dir . FTP_AG93K_PROBER
		EOFFTP`"

cat FTP_AG93K_PROBER | awk '{print $9}'|sed 1,3d | grep -i '^[S|H]' > FTP_AG93K_Prober.txt

######### Interim solution before light vega is implement ###########

#cat FTP_AG93K_PROBER | awk '{print $NF}' |sed 1,3d | grep -i xml$ > FTP_AG93K_Prober.txt

#####################################################################

if [ -s "FTP_AG93K_Prober.txt" ]; then		# check if the file size > 0
	
	SEDA_FTP_FAIL=0 # 20160813

	while read FILE_NAME
	do
		FTP_OUT="`ftp -i -n ${FTPSRC} <<EOFFTP 
	                user ${FTPUSER} ${FTPPASW}
	                bin
					cd ${FTPDIR2}
	                get ${FILE_NAME}
					del ${FILE_NAME}
	                quit
					EOFFTP`"

		ls -l ${FILE_NAME} >> ${HOME}/dp_data/Log/HP93K_PROBER_FTP_RECEIVED-${DATEPART}.log
		#echo "${FILE_NAME} `date`" >> ${Log_Dir}/HP93K_PROBER_FTP_RECEIVED-${DATEPART}.log

		# 20160813
		# Copy file to SEDA folder.
		if [ $SEDA_SRV_STOP == 0 ]; then
    			FILENAME=\"${FILE_NAME}\"
				FTPSTR="`ftp -i -n ${SEDAFTPSRC} <<EOFFTP > ${SEDAFTPLOG}
						user ${SEDAFTPUSER} ${SEDAFTPPASSWD}
						cd ${SEDAFTPDIRSTDF}
						bin
						put ${FILENAME}
						bye
						EOFFTP`"

			EXITFTP=$?

			if [ $EXITFTP -ne 0 ]; then echo "Pre_AG93K_Prober.sh: $EXITFTP" >> ${SEDALOGFILE}; fi

			if fgrep -i "Not connected" ${SEDAFTPLOG} ;then
				echo "${FILE_NAME}: Failed to transfer!" >> ${SEDALOGFILE}

				if [ -d ${SEDADIR} ]; then
					cp -p "${FILE_NAME}" ${SEDADIR}/
				fi

				if [ ${SEDA_FTP_FAIL} == 0 ]; then
					echo "Pre_AG93K_Prober.sh SEDA FTP failure at $(date)" > /tmp/seda_ftp_fail_ag93k_prober_stdf.txt
					mail -s "[SEDA] Pre_AG93K_Prober.sh: FTP Failure at $(date)" $MAILLIST -- -f "${MSENDER}" < /tmp/seda_ftp_fail_ag93k_prober_stdf.txt
					touch seda_job_fail_ag93k_prober_stdf.txt
					mailx -s "Pre_AG93K_Prober.sh SEDA FTP failure at $(date)" $dp_sms < seda_job_fail_ag93k_prober_stdf.txt
					rm seda_job_fail_ag93k_prober_stdf.txt
					SEDA_FTP_FAIL=1
				fi
			else
				echo "${FILE_NAME}: Successfully transfer!" >> ${SEDALOGFILE}
				SEDA_FTP_FAIL=0
			fi
		else
			if [ -d ${SEDADIR} ]; then
				cp -p "${FILE_NAME}" ${SEDADIR}/
			fi
		fi
				
		###### VegaLight Solution - WMAP ##########
		mv ${FILE_NAME} ${Map_Dir} 
		###########################################
		
	done < FTP_AG93K_Prober.txt
	rm ${Temp_Dir}/FTP_AG93K_PROBER ${Temp_Dir}/FTP_AG93K_Prober.txt
else  
 	rm ${Temp_Dir}/FTP_AG93K_PROBER ${Temp_Dir}/FTP_AG93K_Prober.txt
# 	echo "There are no Prober on Test Server!"
 	#exit
fi	

# 20161116
# Copy failed to send files to SEDA folder.
if [ ${SEDA_FTP_FAIL} == 0 ]; then
	cd ${SEDADIR}
	
	ls * -lrt > FTP_FAILED_AG93K_PROBER
	cat FTP_FAILED_AG93K_PROBER | awk '{print $9}'| grep -i '^[S|H]' > FTP_FAILED_PINK.txt
	
	while read FILE_NAME
	do
		
		if [ $SEDA_SRV_STOP == 0 ]; then
				FILENAME=\"${FILE_NAME}\"
				FTPSTR="`ftp -i -n ${SEDAFTPSRC} <<EOFFTP > ${SEDAFTPLOG}
						user ${SEDAFTPUSER} ${SEDAFTPPASSWD}
						cd ${SEDAFTPDIRSTDF}
						bin
						put ${FILENAME}
						bye
						EOFFTP`"
	
			EXITFTP=$?
	
			if [ $EXITFTP -ne 0 ]; then echo "Pre_AG93K_Prober.sh: $EXITFTP" >> ${SEDALOGFILE}; fi
	
			if fgrep -i "Not connected" ${SEDAFTPLOG} ;then
				echo "${FILE_NAME}: Failed to transfer!" >> ${SEDALOGFILE}
	
				if [ ${SEDA_FTP_FAIL} == 0 ]; then
					echo "Pre_AG93K_Prober.sh SEDA FTP failure at $(date)" > /tmp/seda_ftp_fail_ag93k_prober_stdf.txt
					mail -s "[SEDA] Pre_AG93K_Prober.sh: FTP Failure at $(date)" $MAILLIST -- -f "${MSENDER}" < /tmp/seda_ftp_fail_ag93k_prober_stdf.txt
					touch seda_job_fail_ag93k_prober_stdf.txt
					mailx -s "Pre_AG93K_Prober.sh SEDA FTP failure at $(date)" $dp_sms < seda_job_fail_ag93k_prober_stdf.txt
					rm seda_job_fail_ag93k_prober_stdf.txt
					SEDA_FTP_FAIL=1
				fi
			else
				echo "${FILE_NAME}: Successfully transfer!" >> ${SEDALOGFILE}
				rm "${FILE_NAME}"
				SEDA_FTP_FAIL=0
			fi
		fi
	done < FTP_FAILED_PINK.txt

	rm FTP_FAILED_AG93K_PROBER
	rm FTP_FAILED_PINK.txt
fi

if [ ${DEBUG} = 1 ]; then
	echo "End FTP Prober Function"
fi
}

############ END OF FUNCTION FTP PROBER OUTPUT FILE ###################

#### FUNCTION to search the same lot id external data header file #####
search_ED() {
	if [ ${DEBUG} = 1 ]; then
		echo "Wafer ID: $wafid"
		echo "Lot ID: $lotid"
		echo "Prober_Raw_File: $Prober_Raw_File"
		echo "Prober Date: $prober_date"
	fi
	
	cd ${ED_Header_Dir}
	ls $lotid*AG93K.xml | sort > $TEMP2
	
	if [ -s $TEMP2 ]; then
		##### Lin Yun Modify Begin #########
		lastFile=""
		while read ED_File		
		do
			cd ${ED_Header_Dir}
			read firstLine < $ED_File
			## Check if wafer id is in the ED header file
			tmp=`echo "${firstLine}"|awk -F! /$wafid/`
			
			if [ -n "$tmp" ]; then
				## Check if the date of the ED header file is before the date of the prober file
				tmpDate=`echo "${ED_File}" | awk -F_ '{print $2}'|cut -c1-14`
				junk=`expr "$tmpDate" - "$prober_date"`
				
				if [ $junk -le 0 ]; then
					## Link the later ED header file to the prober file
					if [ ${DEBUG} = 1 ]; then
						echo "Matching ED Header file found: $ED_File"
					fi
					lastFile=$ED_File
				else
					if [ $DEBUG = 1 ] ; then
						echo "ED header is $tmpDate and Prober data is $prober_date"
						junk=`expr "$tmpDate" - "$prober_date"`
						echo "ED header is later than prober date"
						echo "Difference is $junk"
					fi
				fi
			fi
		done < $TEMP2
		if [ "$lastFile" = "" ]; then
			## No matching ED Header file is found
			if [ ${DEBUG} = 1 ]; then
				echo "There are no matching ED File for $lotid in SSMC_ED_Header Dir"
			fi
			echo "`date` ${Prober_Raw_File} ${ErrStrB}" >> ${Error_Dir}/AG93K_Prober_${DATEPART}.err
			echo "`date` ${Prober_Raw_File} ${ErrStrB}" > ${MSGFILE}
			
			##Siantar commented this to stop email on 16/9/02
			##mail -s "Error: Agilent Prober Data File" ${MAILLIST} < ${MSGFILE}
			##end of Siantar comment
			
			cd ${Prober_Dir}
			mv ${Prober_Raw_File} ${Prober_NReady_Dir}
		else
			if [ ${DEBUG} = 1 ]; then
				echo "The Last matching ED Header file: $lastFile"
			fi

			# Move the matching ED Hearder file to ED_Processed dir
			FILENAME="`basename $Prober_Raw_File .xml`"
			FILE_TMP="${FILENAME}_ED.xml"
			
			if [ ${DEBUG} = 1 ]; then
				echo "FILENAME : $FILENAME"
				echo "FILE_TMP : $FILE_TMP"
				echo "File size = 1"
			fi

			##### This line CANNOT change to mv only COPY #####
			cp $lastFile ${ED_Pro_Dir}/${FILE_TMP}
			###################################################

			cd ${Prober_Dir}			
			mv $Prober_Raw_File ${Prober_Ready_Dir}
			

		fi
		##### Lin Yun Modify End ###########
	else
		if [ ${DEBUG} = 1 ]; then
			echo "There are no $lotid External Data Header File in SSMC_ED_Header Dir"
		fi
		echo "`date` ${Prober_Raw_File} ${ErrStrA}" >> ${Error_Dir}/AG93K_Prober_${DATEPART}.err
		echo "`date` ${Prober_Raw_File} ${ErrStrA}" > ${MSGFILE}
		cd ${Prober_Dir}
		mv ${Prober_Raw_File} ${Prober_NReady_Dir}
	fi
	rm $TEMP2	
}
############################# End Function Search #############################

###############################################################################
## Purpose : This script preprocess the files coming from the external data header
##	     and the prober putput file
## Author  : TRW, Inc
## Date    : 09 Oct 2001
## Version : Maitence release 0.1      1. Filepaths may be wrong
##				       2. Email has been disabled
##				       3. Clean up has been partially disabled
##				       4. Archiving has been disabled
##				       5. Enable code ( M0.1 )
## Update Date :
## Reason for update :
#################################################################################

PROBER_LOC_PRE() {

if [ ${DEBUG} = 1 ]; then
	echo "Start AG93K Prober Local Preprocessor"
fi

AG93K_PROB_FILE=$1
EXTENSION=$2
FILENAME="`basename $AG93K_PROB_FILE .$EXTENSION`"
#Modified by kelvin on 210705 to remove echo
#echo "FILENAME : ${FILENAME}"

#echo "[`date`] Pre_AG3K_Prober.sh: Start ${AG93K_PROB_FILE}"
cd ${Working_Dir}

lotid=`grep WAFER_OCR_ID ${Prober_Ready_Dir}/${AG93K_PROB_FILE}| sed -e 's/^[ \t]*//' | sed -n 's/<WAFER_OCR_ID>//p' | sed -n 's/<\/WAFER_OCR_ID>//p' | tr '[a-z]' '[A-Z]'`
lotid=`echo "${lotid}"|awk -F\- '{print $1}'`

if [ "z$lotid" = "z" ]; then
	echo "[`date`] Pre_AG3K_Prober.sh: Error ${AG93K_PROB_FILE}"
	mv ${Prober_Ready_Dir}/${AG93K_PROB_FILE} ${Fail_Loc_Prep_Dir}/${AG93K_PROB_FILE}
	tmp_str="Lot id is null for Prober Raw Data File or File is not found"
	echo "`date`\t${Prober_Ready_Dir}/${AG93K_PROB_FILE}" >> ${Err_Dir}/AG93K_Prober_${DATEPART}.err
	echo "`date`\t${AG93K_PROB_FILE} ${ErrStr} ${tmp_str}" >> ${Err_Dir}/AG93K_Prober_${DATEPART}.err
	echo "`date`\t${AG93K_PROB_FILE} ${ErrStr} ${tmp_str}" > ${MSGFILE}
	echo "Lot ID not found." >> ${MSGFILE}
	mail -s "[DATAPOWER] Pre_AG93K_Prober.sh: Error Agilent Prober Data File" ${MAILLIST} -- -f "${MSENDER}" < ${MSGFILE}
	rm ${MSGFILE}
else
	# Process the prober file first
	cp ${Prober_Ready_Dir}/${AG93K_PROB_FILE} ${FILENAME}.tmp
	#  We test for succesful copy operation
	if [  -s  ${FILENAME}.tmp ]; then
	    # strip away the first line of the
	    sed -e '1d' ${FILENAME}.tmp  | more > ${FILENAME}.tmp2
	    #add in the last line
	    echo "</WAFER_DATA>" | cat	>>  ${FILENAME}.tmp2
	     #Now we process the external header file
	     tmpcnt=0
	    cd ${ED_Pro_Dir}
	    #echo "${lotid} lotid"
  
	    shortlotid=`echo "${lotid}"|awk -F\. '{print $1}'`
	    #tmpcnt=`ls ${shortlotid}*.xml | wc -l`
	    tmpcnt=`ls ${FILENAME}*.xml | wc -l`
	    cd ${Working_Dir}

	    if [ $tmpcnt -eq 1 ]; then
		 cd ${ED_Pro_Dir}
		 tmpfilename=`ls ${FILENAME}*.xml`
		 if [ ${DEBUG} = 1 ]; then
		 	echo "TMPFILENAME : $tmpfilename"
		 fi		 
		 cd ${Working_Dir}
		 cp ${ED_Pro_Dir}/${tmpfilename} ${tmpfilename}.tmp
		#  We test for succesful copy operation again
		 if [	-s  ${tmpfilename}.tmp ] ; then
		  sed -e '1d' -e '2d' ${tmpfilename}.tmp  | more > ${tmpfilename}.tmp2
		  #tmp is no longer needed and hence we resue it
		  echo "<?xml version=\"1.0\" ?>" >   ${tmpfilename}.tmp
		  echo	"<WAFER_DATA>" >>   ${tmpfilename}.tmp
		  cat ${tmpfilename}.tmp ${tmpfilename}.tmp2  >${tmpfilename}.tmp3
		  cat  ${tmpfilename}.tmp3 ${FILENAME}.tmp2 >  ${tmpfilename}.tmp4
		  # copy over and we are done
		  cp ${tmpfilename}.tmp4 ${Suc_Loc_Prep_Dir}/${FILENAME}.prob
		  cp ${Suc_Loc_Prep_Dir}/${FILENAME}.prob ${Tyesout_Dir}
		  echo "[`date`] Pre_AG3K_Prober.sh: Success ${AG93K_PROB_FILE}"
		  cd ${Working_Dir}
		  echo "`date`\t${tmpfilename} : ${AG93K_PROB_FILE}:" >> ${Log_Dir}/HP93K_Success_${DATEPART}.log
		  #Do clean up
		  rm  *.tmp*
		  
		 else
		      rm  *.tmp*
		      
		      tmp_str="External Header File is not succesfuly copied. Server could be out of disk space"

		      echo "[`date`] Pre_AG3K_Prober.sh: Error ${AG93K_PROB_FILE}"
		      mv ${Prober_Ready_Dir}/${AG93K_PROB_FILE} ${Fail_Loc_Prep_Dir}/${AG93K_PROB_FILE}
		      echo "`date`\t${AG93K_PROB_FILE} ${ErrStr} ${tmpstr}" >> ${Error_Dir}/AG93K_Prober_${DATEPART}.err
		      echo "`date`\t${AG93K_PROB_FILE} ${ErrStr} ${tmpstr}" > ${MSGFILE}
		      echo "File is not succesfuly copied. Server could be out of disk space." >> ${MSGFILE}
		      mail -s "[DATAPOWER] Pre_AG93K_Prober.sh: Error Agilent Prober Data File" ${MAILLIST} -- -f "${MSENDER}" < ${MSGFILE}
		      rm ${MSGFILE}

		 fi

	      else
		     rm	*.tmp*
                     tmp_str="Duplicate or no header file found"
		      echo "[`date`] Pre_AG3K_Prober.sh: Error ${AG93K_PROB_FILE}"
		      mv ${Prober_Ready_Dir}/${AG93K_PROB_FILE} ${Fail_Loc_Prep_Dir}/${AG93K_PROB_FILE}
		      echo "`date`\t${AG93K_PROB_FILE} ${ErrStr} ${tmpstr}" >> ${Error_Dir}/AG93K_Prober_${DATEPART}.err
		      echo "`date`\t${AG93K_PROB_FILE} ${ErrStr} ${tmpstr}" > ${MSGFILE}
		      echo "Duplicate or no header file found." >> ${MSGFILE}
		      mail -s "[DATAPOWER] Pre_AG93K_Prober.sh: Error Agilent Prober Data File" ${MAILLIST} -- -f "${MSENDER}" < ${MSGFILE}
		      rm ${MSGFILE}
	      fi

	 else
		      rm  *.tmp*
		      tmp_str="Copy of Prober Raw data file failed - Server could be out of space."
		   
		      echo "[`date`] Pre_AG3K_Prober.sh: Error ${AG93K_PROB_FILE}"
		      mv ${AG93K_PROB_FILE} ${Fail_Loc_Prep_Dir}/${AG93K_PROB_FILE}			    
		      echo "`date`\t${AG93K_PROB_FILE} ${ErrStr} ${tmpstr}" >> ${Error_Dir}/AG93K_Prober_${DATEPART}.err
		      echo "`date`\t${AG93K_PROB_FILE} ${ErrStr} ${tmpstr}" > ${MSGFILE}
		      echo "Copy of file failed - Server could be out of space." >> ${MSGFILE}
		      mail -s "[DATAPOWER] Pre_AG93K_Prober.sh: Error Agilent Prober Data File" ${MAILLIST} -- -f "${MSENDER}" < ${MSGFILE}
		      rm ${MSGFILE}
	 fi
 fi
 
if [ ${DEBUG} = 1 ]; then
 	echo "End AG93K Prober Local Preprocessor"
fi
 
}

################# End Prober local Preprocessor #######

################# Main Program ########################
cd ${Temp_Dir}
Checking_Processes

# 20160813
# Verify SEDA MS101 server is up and running.
SEDA_FTP_FAIL=0 # 20161118
SEDA_SRV_STOP=0
count=`ping $SEDAFTPSRC -c 1 |  grep 'received' | awk -F',' '{ print $2 }' | awk -F' ' '{ print $1 }'`

if [ $count -eq 0 ]; then
        echo "Host: $SEDAFTPSRC is down (ping failed) at $(date)" >> ${Log_Dir}/HP93K_Prober_Job_${DATEPART}.log
        echo "Host: $SEDAFTPSRC is down (ping failed) at $(date)" >> /tmp/ping_fail_HP93K_Prober.txt
	mail -s "[SEDA] Pre_AG93K_Prober.sh: $SEDAFTPSRC is down (ping failed) at $(date)" $MAILLIST -- -f "${MSENDER}" < /tmp/ping_fail_HP93K_Prober.txt
        touch job_fail_HP93K_Prober.txt
        mailx -s "Host: $SEDAFTPSRC is down (ping failed) at $(date)" $dp_sms < job_fail_HP93K_Prober.txt
        rm job_fail_HP93K_Prober.txt
        SEDA_SRV_STOP=1
fi

################# Start FTP Session ###################
cd ${Temp_Dir}
FTP_EDH
cd ${Temp_Dir}
echo "Executing retrieval of prober map"
FTP_Prober

################## End FTP Session ####################

 cd ${Map_Dir}

# Added by EW (01-Dec-2004).
for Map_File in S*
do
	${WMAP} ${Map_File}
	if [ -f $Map_File ] ; then 
	${HOME}/dp_data/Script/Archive_File.sh ${Map_File} ${HOME}/dp_data/Archive/test_data/SSMC_SR_HP93K_Prober/HP93K_Prober "M"
	fi 
done

for Map_File in H*
do
	${WMAP} ${Map_File}
	if [ -f $Map_File ] ; then
	${HOME}/dp_data/Script/Archive_File.sh ${Map_File} ${HOME}/dp_data/Archive/test_data/SSMC_SR_HP93K_Prober/HP93K_Prober "M"
	fi
done

mv *.xml ${Prober_Dir} 2> /dev/null 

########### End VegaLight Solution - WMAP #############

################# Preprocess Session Start ############

cd ${Prober_Dir}

ls > $TEMP1

if [ -s $TEMP1 ]; then

	while read Prober_Raw_File
	do 
		lotid=`grep WAFER_OCR ${Prober_Raw_File}| sed -e 's/^[ \t]*//' | sed -n 's/<WAFER_OCR_ID>//p' | sed -n 's/<\/WAFER_OCR_ID>//p' | tr '[A-Z]' '[a-z]'`
		lotid=`echo "${lotid}"|awk -F\- '{print $1}'`

		##### Lin Yun Modify Begin #########
		wafid=`echo "${Prober_Raw_File}"|awk -F- '{print $2}'|cut -c1-2`
		prober_date=`echo "${Prober_Raw_File}"|awk -F_ '{print $2}'|cut -c1-15|awk -F\- '{print $1 $2}'`
		search_ED $lotid $Prober_Raw_File $wafid $prober_date
		##### Lin Yun Modify End  ##########
		cd ${Prober_Dir}
	done < $TEMP1
	rm $TEMP1
else
	exit
fi

##### Pass the correct argument to the Prober Local Preprocessor #####

cd $Prober_Ready_Dir

ls > $TEMP3

if [ -s $TEMP3 ]; then

	while read Prober_XML_File
	do
		cd $Prober_Ready_Dir
		
		if [ ${DEBUG} = 1 ]; then
			echo "This is the Local Preprocess Directory - ${Prober_XML_File}"
		fi
		
		PROBER_LOC_PRE $Prober_XML_File xml
	done < $TEMP3	

	rm $TEMP3

	if [ ${DEBUG} = 1 ]; then
		echo "End of Pre_AG3K_Prober_LY.sh"
	fi	
else 
	if [ ${DEBUG} = 1 ]; then
		echo "Prober Ready Dir - No File !!"
		echo "End of Pre_AG3K_Prober.sh"
	fi
	rm $TEMP3
	exit	
fi

####################### END MAIN PROGRAM #############################
