/**
 * $Id: PrrRecord.cs 9 2006-09-21 22:13:20Z outburst $
 * 
 * STDFSharp
 *
 * File: PrrRecord.cs
 * Description:
 * 
 * Copyright (C) 2006 Outburst <outburst@users.sourceforge.net>
 *  
 * This library is free software; you can redistribute it and/or 
 * modify it under the terms of the GNU Lesser General Public License 
 * as published by the Free Software Foundation; either version 2.1 
 * of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful, 
 * but WITHOUT ANY WARRANTY; without even the implied warranty of 
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this library; if not, write to the Free Software Foundation, 
 * Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */

using System;
using KA.StdfSharp.Record.Field;
using String=KA.StdfSharp.Record.Field.String;

namespace KA.StdfSharp.Record
{
    /// <summary>
    /// Represents the PRR record of STDF
    /// </summary>
    [StdfRecord(5, 20)]
    public class PrrRecord : StdfRecord
    {
        private IField<byte>        headNumber; // HEAD_NUM U*1 Test head number
        private IField<byte>        siteNumber; // SITE_NUM U*1 Test site number
        private IBitField           partFlag; // PART_FLG B*1 Part information flag
        private IField<ushort>      testExecutedCount; // NUM_TEST U*2 Number of tests executed
        private IField<ushort>      hardwareBin; // HARD_BIN U*2 Hardware bin number
        private IField<ushort>      softwareBin; // SOFT_BIN U*2 Software bin number
        private IField<short>       xCoordinate; // X_COORD I*2 (Wafer) X coordinate
        private IField<short>       yCoordinate; // Y_COORD I*2 (Wafer) Y coordinate
        private IField<DateTime>    elapsedTestTime; // TEST_T U*4 Elapsed test time in milliseconds
        private IField<string>      partIdentification; // PART_ID C*n Part identification
        private IField<string>      partDescription; // PART_TXT C*n Part description text
        private IField<byte[]>      partRepairInformation; // PART_FIX B*n Part repair information

        public PrrRecord()
        {
            headNumber              = new UByte();
            siteNumber              = new UByte();
            partFlag                = new PartFlagField();
            testExecutedCount       = new UShort();
            hardwareBin             = new UShort();
            softwareBin             = new UShort();
            xCoordinate             = new Short();
            yCoordinate             = new Short();
            elapsedTestTime         = new Date();
            partIdentification      = new String();
            partDescription         = new String();
            partRepairInformation   = new VariableBitEncoded<PrrRecord>(this);
            
            AddField("HEAD_NUM", headNumber);
            AddField("SITE_NUM", siteNumber);
            AddField("PART_FLG", partFlag);
            AddField("NUM_TEST", testExecutedCount);
            AddField("HARD_BIN", hardwareBin);
            AddField("SOFT_BIN", softwareBin);
            AddField("X_COORD", xCoordinate);
            AddField("Y_COORD", yCoordinate);
            AddField("TEST_T", elapsedTestTime);
            AddField("PART_ID", partIdentification);
            AddField("PART_TXT", partDescription);
            AddField("PART_FIX", partRepairInformation);
        }
        
        public bool SupersedePartIdSequence
        {
            get
            {
                return !(partFlag.EvaluateAnd((byte)PartFlagBit.SupersedePartIdSequence));
            }
        }

        public bool SupersedeCoordinateSequence
        {
            get
            {
                return !(partFlag.EvaluateAnd((byte)PartFlagBit.SupersedeCoordinateSequence));
            }
        }
        
        public bool TestNormallyCompleted
        {
            get
            {
                return partFlag.EvaluateAnd((byte)PartFlagBit.TestNormallyCompleted);
            }
        }
        
        public bool PartPassed
        {
            get
            {
                return partFlag.EvaluateAnd((byte)PartFlagBit.TestFailed);
            }
        }

        public bool PassFailFlagValid
        {
            get
            {
                return partFlag.EvaluateAnd((byte)PartFlagBit.NoPassFailFlag);
            }
        }

        public IField<byte> HeadNumber
        {
            get { return headNumber; }
        }

        public IField<byte> SiteNumber
        {
            get { return siteNumber; }
        }

        public IField<ushort> TestExecutedCount
        {
            get { return testExecutedCount; }
        }

        public IField<ushort> HardwareBin
        {
            get { return hardwareBin; }
        }

        public IField<ushort> SoftwareBin
        {
            get { return softwareBin; }
        }

        public IField<short> XCoordinate
        {
            get { return xCoordinate; }
        }

        public IField<short> YCoordinate
        {
            get { return yCoordinate; }
        }

        public IField<DateTime> ElapsedTestTime
        {
            get { return elapsedTestTime; }
        }

        public IField<string> PartIdentification
        {
            get { return partIdentification; }
        }

        public IField<string> PartDescription
        {
            get { return partDescription; }
        }

        public IField<byte[]> PartRepairInformation
        {
            get { return partRepairInformation; }
        }

        /// <summary>
        /// Represents the field PART_FLG of PRR record.
        /// </summary>
        /// <remarks>From STDF specification the first two bit must not be set both to 1. 
        /// So it possibile to check if it happens checking the validity of this field through <see cref="IField.IsValid"/></remarks>
        public IField<byte> PartFlag
        {
            get { return partFlag; }
        }

        private class PartFlagField : BitEncoded<PrrRecord>
        {
            /// <summary>
            /// Validate the field's value.
            /// </summary>
            /// <remarks>Each subclasses should override to validate field's value.</remarks>
            protected override void DoValidate()
            {
                if (!(EvaluateAnd((byte)PartFlagBit.SupersedePartIdSequence)) && !(EvaluateAnd((byte)PartFlagBit.SupersedeCoordinateSequence)))
                    Valid = false;
            }
        }

        [Flags]
        private enum PartFlagBit : byte
        {
            Unknown = 0x00,
            SupersedePartIdSequence = 0x01,
            SupersedeCoordinateSequence = 0x02,
            TestNormallyCompleted = 0x04,
            TestFailed = 0x08,
            NoPassFailFlag = 0x10,
            All = 0xff
        }
    }
}