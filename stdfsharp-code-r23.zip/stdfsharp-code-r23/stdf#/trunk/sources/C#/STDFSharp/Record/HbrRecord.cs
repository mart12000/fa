/**
 * $Id: HbrRecord.cs 8 2006-09-11 05:36:47Z Angelo $
 * 
 * STDFSharp
 *
 * File: HbrRecord.cs
 * Description:
 * 
 * Copyright (C) 2006 Outburst <outburst@users.sourceforge.net>
 *  
 * This library is free software; you can redistribute it and/or 
 * modify it under the terms of the GNU Lesser General Public License 
 * as published by the Free Software Foundation; either version 2.1 
 * of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful, 
 * but WITHOUT ANY WARRANTY; without even the implied warranty of 
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this library; if not, write to the Free Software Foundation, 
 * Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */

using KA.StdfSharp.Record.Field;
using Char=KA.StdfSharp.Record.Field.Char;
using String=KA.StdfSharp.Record.Field.String;

namespace KA.StdfSharp.Record
{
    public enum HardwareBinStatus
    {
        Unknown,
        Passed,
        Fail
    }

    /// <summary>
    /// Represents the HBR record of STDF.
    /// </summary>
    [StdfRecord(1, 40)]
    public sealed class HbrRecord : StdfRecord
    {
        private const char PassedStatus = 'P';
        private const char FailStatus = 'F';
        private const char UnknownStatus = ' ';
        private IField<byte>    headNumber  = new UByte(); // HEAD_NUM U*1 Test head number
        private IField<byte>    siteNumber  = new UByte(); // SITE_NUM U*1 Test site number
        private IField<ushort>  number      = new UShort(); // HBIN_NUM U*2 Hardware bin number
        private IField<uint>    partsCount  = new UInt(); // HBIN_CNT U*4 Number of parts in bin
        private IField<char>    passFail    = new Char(); // HBIN_PF C*1 Pass/fail indication
        private IField<string>  name        = new String(); // HBIN_NAM C*n Name of hardware bin

        public enum FieldName
        {
            HEAD_NUM,
            SITE_NUM,
            HBIN_NUM,
            HBIN_CNT,
            HBIN_PF,
            HBIN_NAM
        }
        
        public HbrRecord()
        {
            AddField(FieldName.HEAD_NUM.ToString(), headNumber);
            AddField(FieldName.SITE_NUM.ToString(), siteNumber);
            AddField(FieldName.HBIN_NUM.ToString(), number);
            AddField(FieldName.HBIN_CNT.ToString(), partsCount);
            AddField(FieldName.HBIN_PF.ToString(), passFail);
            AddField(FieldName.HBIN_NAM.ToString(), name);
        }
        
        public HardwareBinStatus Status
        {
            get
            {
                switch(passFail.Value)
                {
                    case PassedStatus:
                        return HardwareBinStatus.Passed;
                    case FailStatus:
                        return HardwareBinStatus.Fail;
                    default:
                        return HardwareBinStatus.Unknown;    
                }
            }
            
            set
            {
                switch (value)
                {
                    case HardwareBinStatus.Passed:
                        PassFail.Value = PassedStatus;
                        break;
                    case HardwareBinStatus.Fail:
                        PassFail.Value = FailStatus;
                        break;
                    default:
                        PassFail.Value = UnknownStatus;
                        break;
                }
            }
        }

        public IField<byte> HeadNumber
        {
            get { return headNumber; }
        }

        public IField<byte> SiteNumber
        {
            get { return siteNumber; }
        }

        public IField<ushort> Number
        {
            get { return number; }
        }

        public IField<uint> PartsCount
        {
            get { return partsCount; }
        }

        private IField<char> PassFail
        {
            get { return passFail; }
        }

        public IField<string> Name
        {
            get { return name; }
        }
    }
}