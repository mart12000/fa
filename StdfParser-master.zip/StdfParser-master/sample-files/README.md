# SAMPLE STDF FILES

## GalaxySemi

The galaxysemi-* files are from <https://sourceforge.net/p/freestdf/svn/22/>, which
in turn says they came from <http://www.galaxysemi.com/examinatordb/support/install.htm>
however at the time of this writing, the galaxysemi website is timing out.
