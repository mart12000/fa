/**
 * $Id: SbrRecord.cs 8 2006-09-11 05:36:47Z Angelo $
 * 
 * STDFSharp
 *
 * File: HbrRecord.cs
 * Description:
 * 
 * Copyright (C) 2006 Outburst <outburst@users.sourceforge.net>
 *  
 * This library is free software; you can redistribute it and/or 
 * modify it under the terms of the GNU Lesser General Public License 
 * as published by the Free Software Foundation; either version 2.1 
 * of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful, 
 * but WITHOUT ANY WARRANTY; without even the implied warranty of 
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this library; if not, write to the Free Software Foundation, 
 * Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */

using KA.StdfSharp.Record.Field;

namespace KA.StdfSharp.Record
{
    public enum SoftwareBinStatus
    {
        Unknown,
        Passed,
        Fail
    }

    /// <summary>
    /// Represents the SBR record of STDF.
    /// </summary>
    [StdfRecord(1, 50)]
    public sealed class SbrRecord : StdfRecord
    {
        private IField<byte>    headNumber  = new UByte(); // HEAD_NUM U*1 Test head number
        private IField<byte>    siteNumber  = new UByte(); // SITE_NUM U*1 Test site number
        private IField<ushort>  number      = new UShort(); // SBIN_NUM U*2 Software bin number
        private IField<uint>    partsCount  = new UInt(); // SBIN_CNT U*4 Number of parts in bin
        private IField<char>    passFail    = new Char(); // SBIN_PF C*1 Pass/fail indication
        private IField<string>  name        = new String(); // SBIN_NAM C*n Name of software bin


        public SbrRecord()
        {
            AddField("HEAD_NUM", headNumber);
            AddField("SITE_NUM", siteNumber);
            AddField("HBIN_NUM", number);
            AddField("HBIN_CNT", partsCount);
            AddField("HBIN_PF", passFail);
            AddField("HBIN_NAM", name);
        }

        public SoftwareBinStatus Status
        {
            get
            {
                switch(passFail.Value)
                {
                    case 'P':
                        return SoftwareBinStatus.Passed;
                    case 'F':
                        return SoftwareBinStatus.Fail;
                    default:
                        return SoftwareBinStatus.Unknown;    
                }
            }
        }

        public IField<byte> HeadNumber
        {
            get { return headNumber; }
        }

        public IField<byte> SiteNumber
        {
            get { return siteNumber; }
        }

        public IField<ushort> Number
        {
            get { return number; }
        }

        public IField<uint> PartsCount
        {
            get { return partsCount; }
        }

        public IField<char> PassFail
        {
            get { return passFail; }
        }

        public IField<string> Name
        {
            get { return name; }
        }
    }
}