/**
 * $Id: PtrRecord.cs 9 2006-09-21 22:13:20Z outburst $
 * 
 * STDFSharp
 *
 * File: PtrRecord.cs
 * Description:
 * 
 * Copyright (C) 2006 Outburst <outburst@users.sourceforge.net>
 *  
 * This library is free software; you can redistribute it and/or 
 * modify it under the terms of the GNU Lesser General Public License 
 * as published by the Free Software Foundation; either version 2.1 
 * of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful, 
 * but WITHOUT ANY WARRANTY; without even the implied warranty of 
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this library; if not, write to the Free Software Foundation, 
 * Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */

using KA.StdfSharp.Record.Field;

namespace KA.StdfSharp.Record
{
    [StdfRecordAttribute(15, 10)]
    public class PtrRecord : StdfRecord
    {
        private IField<uint>    testNumber              = new UInt(); // TEST_NUM U*4 Test number
        private IField<byte>    headNumber              = new UByte(); // HEAD_NUM U*1 Test head number
        private IField<byte>    siteNumber              = new UByte(); // SITE_NUM U*1 Test site number
        private IBitField       testFlags               = null; // TEST_FLG B*1 Test flags (fail, alarm, etc.)
        private IBitField       parametricFlags         = null; // PARM_FLG B*1 Parametric test flags (drift, etc.)
        private IField<float>   result                  = new Float(); // RESULT R*4 Test result
        private IField<string>  testLabel               = new String(); // TEST_TXT C*n Test description text or label
        private IField<string>  alarmName               = new String(); // ALARM_ID C*n Name of alarm
        private IBitField       optionalflag            = null; // OPT_FLAG B*1 Optional data flag
        private IField<byte>    resultScale             = null; // RES_SCAL I*1 Test results scaling exponent
        private IField<byte>    lowLimitScale           = null; // LLM_SCAL I*1 Low limit scaling exponent
        private IField<byte>    highLimitScale          = null; // HLM_SCAL I*1 High limit scaling exponent
        private IField<float>   lowLimit                = new Float(); // LO_LIMIT R*4 Low test limit value
        private IField<float>   highLimit               = new Float(); // HI_LIMIT R*4 High test limit value
        private IField<string>  units                   = new String(); // UNITS C*n Test units
        private IField<string>  resultFormat            = new String(); // C_RESFMT C*n ANSI C result format string
        private IField<string>  lowLimitFormat          = new String(); // C_LLMFMT C*n ANSI C low limit format string
        private IField<string>  highLimitFormat         = new String(); // C_HLMFMT C*n ANSI C high limit format string
        private IField<float>   lowSpecificationLimit   = new Float(); // LO_SPEC R*4 Low specification limit value
        private IField<float>   highSpecificationLimit  = new Float(); // HI_SPEC R*4 High specification limit value
        
        // TODO To complete
    }
}