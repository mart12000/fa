/**
 * $Id: MirRecord.cs 8 2006-09-11 05:36:47Z Angelo $
 * 
 * STDFSharp - Reading/writing STDF (Standard Test Data Format) library for .NET
 *
 * File: MirRecord.cs
 * Description:
 * 
 * Copyright (C) 2006 Outburst <outburst@users.sourceforge.net>
 *  
 * This library is free software; you can redistribute it and/or 
 * modify it under the terms of the GNU Lesser General Public License 
 * as published by the Free Software Foundation; either version 2.1 
 * of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful, 
 * but WITHOUT ANY WARRANTY; without even the implied warranty of 
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this library; if not, write to the Free Software Foundation, 
 * Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */

using KA.StdfSharp.Record.Field;
using Char=KA.StdfSharp.Record.Field.Char;
using String=KA.StdfSharp.Record.Field.String;

namespace KA.StdfSharp.Record
{
    /// <summary>
    /// Represents the MIR record of STDF
    /// </summary>
    [StdfRecord(1, 10)]
    public sealed class MirRecord : StdfRecord
    {
        private IField<uint>    jobSetupDate                    = new UInt(); // SETUP_T U*4 Date and time of job setup
        private IField<uint>    firstPartTestedDate             = new UInt(); // START_T U*4 Date and time first part tested
        private IField<byte>    testerStationNumber             = new UByte(); // STAT_NUM U*1 Tester station number
        private IField<char>    testModeCode                    = new Char(); // MODE_COD C*1 Test mode code (e.g. prod, dev) space
        private IField<char[]>  lotRetestCode                   = new FixedLengthCharacter(1); // RTST_COD C*1 Lot retest code space
        private IField<char[]>  dataProtectionCode              = new FixedLengthCharacter(1); // PROT_COD C*1 Data protection code space
        private IField<ushort>  burnTime                        = new UShort(); // BURN_TIM U*2 Burn-in time (in minutes) 
        private IField<char>    commandModeCode                 = new Char(); // CMOD_COD C*1 Command mode code space
        private IField<string>  lotId                           = new String(); // LOT_ID C*n Lot ID (customer specified)
        private IField<string>  partType                        = new String(); // PART_TYP C*n Part Type (or product ID)
        private IField<string>  nodeName                        = new String(); // NODE_NAM C*n Name of node that generated data
        private IField<string>  testerType                      = new String(); // TSTR_TYP C*n Tester type
        private IField<string>  jobName                         = new String(); // JOB_NAM C*n Job name (test program name)
        private IField<string>  jobRevision                     = new String(); // JOB_REV C*n Job (test program) revision number 
        private IField<string>  subLotId                        = new String(); // SBLOT_ID C*n Sublot ID 
        private IField<string>  operatorName                    = new String(); // OPER_NAM C*n Operator name or ID (at setup time) 
        private IField<string>  testerExecutiveSoftwareType     = new String(); // EXEC_TYP C*n Tester executive software type
        private IField<string>  testerExecutiveSoftwareVersion  = new String(); // EXEC_VER C*n Tester exec software version number
        private IField<string>  testPhaseCode                   = new String(); // TEST_COD C*n Test phase or step code
        private IField<string>  testTemperature                 = new String(); // TST_TEMP C*n Test temperature
        private IField<string>  userText                        = new String(); // USER_TXT C*n Generic user text
        private IField<string>  auxiliaryDataFile               = new String(); // AUX_FILE C*n Name of auxiliary data file length
        private IField<string>  packageType                     = new String(); // PKG_TYP C*n Package type length
        private IField<string>  familyId                        = new String(); // FAMLY_ID C*n Product family ID 
        private IField<string>  dateCode                        = new String(); // DATE_COD C*n Date code
        private IField<string>  testFacilityId                  = new String(); // FACIL_ID C*n Test facility ID 
        private IField<string>  testFloorId                     = new String(); // FLOOR_ID C*n Test floor ID length byte = 0
        private IField<string>  fabricationProcessId            = new String(); // PROC_ID C*n Fabrication process ID 
        private IField<string>  operationFrequency              = new String(); // OPER_FRQ C*n Operation frequency or step
        private IField<string>  testSpecificationName           = new String(); // SPEC_NAM C*n Test specification name
        private IField<string>  testSpecificationVersion        = new String(); // SPEC_VER C*n Test specification version number
        private IField<string>  testFlowId                      = new String(); // FLOW_ID C*n Test flow ID
        private IField<string>  testSetupId                     = new String(); // SETUP_ID C*n Test setup ID 
        private IField<string>  deviceDesignRevision            = new String(); // DSGN_REV C*n Device design revision 
        private IField<string>  engineeringLotId                = new String(); // ENG_ID C*n Engineering lot ID 
        private IField<string>  romCodeId                       = new String(); // ROM_COD C*n ROM code ID 
        private IField<string>  testerSerialNumber              = new String(); // SERL_NUM C*n Tester serial number 
        private IField<string>  supervisorName                  = new String(); // SUPR_NAM C*n Supervisor name or ID

        public MirRecord()
        {
            AddField("SETUP_T", jobSetupDate);
            AddField("START_T", firstPartTestedDate);
            AddField("STAT_NUM", testerStationNumber);
            AddField("MODE_COD", testModeCode);
            AddField("RTST_COD", lotRetestCode);
            AddField("PROT_COD", dataProtectionCode);
            AddField("BURN_TIM", burnTime);
            AddField("CMOD_COD", commandModeCode);
            AddField("LOT_ID", lotId);
            AddField("PART_TYP", partType);
            AddField("NODE_NAM", nodeName);
            AddField("TSTR_TYP", testerType);
            AddField("JOB_NAM", jobName);
            AddField("JOB_REV", jobRevision);
            AddField("SBLOT_ID", subLotId);
            AddField("OPER_NAM", operatorName);
            AddField("EXEC_TYP", testerExecutiveSoftwareType);
            AddField("EXEC_VER", testerExecutiveSoftwareVersion);
            AddField("TEST_COD", testPhaseCode);
            AddField("TST_TEMP", testTemperature);
            AddField("USER_TXT", userText);
            AddField("AUX_FILE", auxiliaryDataFile);
            AddField("PKG_TYP", packageType);
            AddField("FAMLY_ID", familyId);
            AddField("DATE_COD", dateCode);
            AddField("FACIL_ID", testFacilityId);
            AddField("FLOOR_ID", testFloorId);
            AddField("PROC_ID", fabricationProcessId);
            AddField("OPER_FRQ", operationFrequency);
            AddField("SPEC_NAM", testSpecificationName);
            AddField("SPEC_VER", testSpecificationVersion);
            AddField("FLOW_ID", testFlowId);
            AddField("SETUP_ID", testSetupId);
            AddField("DSGN_REV", deviceDesignRevision);
            AddField("ENG_ID", engineeringLotId);
            AddField("ROM_COD", romCodeId);
            AddField("SERL_NUM", testerSerialNumber);
            AddField("SUPR_NAM", supervisorName);
        }

        public IField<uint> JobSetupDate
        {
            get { return jobSetupDate; }
        }

        public IField<uint> FirstPartTestedDate
        {
            get { return firstPartTestedDate; }
        }

        public IField<byte> TesterStationNumber
        {
            get { return testerStationNumber; }
        }

        public IField<char> TestModeCode
        {
            get { return testModeCode; }
        }

        public IField<char[]> LotRetestCode
        {
            get { return lotRetestCode; }
        }

        public IField<char[]> DataProtectionCode
        {
            get { return dataProtectionCode; }
        }

        public IField<ushort> BurnTime
        {
            get { return burnTime; }
        }

        public IField<char> CommandModeCode
        {
            get { return commandModeCode; }
        }

        public IField<string> LotId
        {
            get { return lotId; }
        }

        public IField<string> PartType
        {
            get { return partType; }
        }

        public IField<string> NodeName
        {
            get { return nodeName; }
        }

        public IField<string> TesterType
        {
            get { return testerType; }
        }

        public IField<string> JobName
        {
            get { return jobName; }
        }

        public IField<string> JobRevision
        {
            get { return jobRevision; }
        }

        public IField<string> SubLotId
        {
            get { return subLotId; }
        }

        public IField<string> OperatorName
        {
            get { return operatorName; }
        }

        public IField<string> TesterExecutiveSoftwareType
        {
            get { return testerExecutiveSoftwareType; }
        }

        public IField<string> TesterExecutiveSoftwareVersion
        {
            get { return testerExecutiveSoftwareVersion; }
        }

        public IField<string> TestPhaseCode
        {
            get { return testPhaseCode; }
        }

        public IField<string> TestTemperature
        {
            get { return testTemperature; }
        }

        public IField<string> UserText
        {
            get { return userText; }
        }

        public IField<string> AuxiliaryDataFile
        {
            get { return auxiliaryDataFile; }
        }

        public IField<string> PackageType
        {
            get { return packageType; }
        }

        public IField<string> FamilyId
        {
            get { return familyId; }
        }

        public IField<string> DateCode
        {
            get { return dateCode; }
        }

        public IField<string> TestFacilityId
        {
            get { return testFacilityId; }
        }

        public IField<string> TestFloorId
        {
            get { return testFloorId; }
        }

        public IField<string> FabricationProcessId
        {
            get { return fabricationProcessId; }
        }

        public IField<string> OperationFrequency
        {
            get { return operationFrequency; }
        }

        public IField<string> TestSpecificationName
        {
            get { return testSpecificationName; }
        }

        public IField<string> TestSpecificationVersion
        {
            get { return testSpecificationVersion; }
        }

        public IField<string> TestFlowId
        {
            get { return testFlowId; }
        }

        public IField<string> TestSetupId
        {
            get { return testSetupId; }
        }

        public IField<string> DeviceDesignRevision
        {
            get { return deviceDesignRevision; }
        }

        public IField<string> EngineeringLotId
        {
            get { return engineeringLotId; }
        }

        public IField<string> RomCodeId
        {
            get { return romCodeId; }
        }

        public IField<string> TesterSerialNumber
        {
            get { return testerSerialNumber; }
        }

        public IField<string> SupervisorName
        {
            get { return supervisorName; }
        }
   }
}