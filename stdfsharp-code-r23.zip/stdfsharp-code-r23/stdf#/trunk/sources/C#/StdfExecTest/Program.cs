using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using KA.StdfSharp;
using KA.StdfSharp.Record;

namespace StdfExecTest
{
    class Program
    {
        private static readonly string filePath = Path.GetFullPath(@"..\..\..\..\..\stdf\stdf_test.std");
        
        static void Main(string[] args)
        {
            using (FileStream stream = File.OpenRead(filePath))
            {
                using (StdfFileReader reader = new StdfFileReader(stream))
                {
                    reader.RegisterDelegate(0, 10, delegate(object o, RecordReadEventArgs e)
                                                       {
                                                           Console.WriteLine(e.Record);
                                                       });
                    reader.RegisterDelegate(0, 20, delegate(object o, RecordReadEventArgs e)
                                                       {
                                                           Console.WriteLine(e.Record);
                                                       });
                    reader.RegisterDelegate(1, 20, delegate(object o, RecordReadEventArgs e)
                                                       {
                                                           Console.WriteLine(e.Record);
                                                       });
                    reader.Read();
                }
            }
        }
    }
}
