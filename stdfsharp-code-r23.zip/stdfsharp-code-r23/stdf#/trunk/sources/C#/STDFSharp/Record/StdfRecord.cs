/**
 * $Id: StdfRecord.cs 8 2006-09-11 05:36:47Z Angelo $
 * 
 * STDFSharp - Reading/writing STDF (Standard Test Data Format) library for .NET
 *
 * File: StdfRecord.cs
 * Description: 
 * 
 * Copyright (C) 2006 Outburst <outburst@users.sourceforge.net>
 *  
 * This library is free software; you can redistribute it and/or 
 * modify it under the terms of the GNU Lesser General Public License 
 * as published by the Free Software Foundation; either version 2.1 
 * of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful, 
 * but WITHOUT ANY WARRANTY; without even the implied warranty of 
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
 * GNU Lesser General Public License for more details.
 */

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using KA.StdfSharp.Properties;
using KA.StdfSharp.Record.Field;

namespace KA.StdfSharp.Record
{ 
    public abstract class StdfRecord : IBinaryStorable
    {
        private Dictionary<string, IField> fields;
        private List<IField> fieldList;

        private readonly StdfHeader header;

        private StdfRecordAttribute attribute;
        
        protected StdfRecord()
        {
            attribute = GetStdfRecordAttribute(GetType());
            fields = new Dictionary<string, IField>();
            fieldList = new List<IField>();

            header = new StdfHeader();
        }

        public byte Type
        {
            get { return attribute.Type;  }
        }

        public byte Subtype
        {
            get { return attribute.Subtype; }
        }
        
        /// <summary>
        /// Returns a field named <code>name</code>.
        /// </summary>
        /// <param name="name">The name of the field.</param>
        /// <returns>A <see cref="IField"/>.</returns>
        public IField this[string name]
        {
            get
            {
                IField field;
                if (!fields.TryGetValue(name, out field))
                    return null;
                return field;
            }
        }
        
        /// <summary>
        /// Add a field to this record.
        /// </summary>
        /// <param name="field">The field to add.</param>
        /// <remarks>Each subclasses must add its fields in a ordered way, 
        /// the same used to read and write these fields from and to the STDF file.</remarks>
        internal protected void AddField(string name, IField field)
        {
            fields.Add(name, field);
            fieldList.Add(field);
        }

        /// <summary>
        /// Reads a record form the binary reader.
        /// </summary>
        /// <param name="reader">The binary reader used to read the record.</param>
        public void Read(BinaryReader reader)
        {
            if (reader == null)
                throw new ArgumentNullException("reader", Resources.ObjectCannotBeNull);
            
            if (reader.PeekChar() == -1)
                return;

            foreach (IField field in fieldList)
            {
                if (reader.PeekChar() == -1)
                    return;
                field.Read(reader);
                field.Validate();
            }
        }

        public void ValidateFields()
        {
            foreach (IField field in fieldList)
            {
                field.Validate();
            }
        }

        /// <summary>
        /// Writes the header of each records and delegates the writing of fields to subclasses.
        /// </summary>
        /// <param name="writer">The writer where to write the record</param>
        public virtual void Write(BinaryWriter writer)
        {
            if (writer == null)
                throw new ArgumentNullException("writer", Resources.ObjectCannotBeNull);
            
            WriteHeader(writer);

            foreach (IField field in fieldList)
                field.Write(writer);
            writer.Flush();
        }

        private void WriteHeader(BinaryWriter writer)
        {
            Debug.Assert(header != null);
            header.Lenght = Length;
            header.Type = attribute.Type;
            header.Subtype = attribute.Subtype;
            header.Write(writer);
        }

        /// <summary>
        /// Returns the length in bytes automatically calculated summing the size of each fields of the record.
        /// </summary>
        /// <remarks>By reflection, all fields of the class that implements <code>IField</code> interface are searched. 
        /// Then, for each <code>IField</code>, the value of the <code>Size</code> property is requested to calculate 
        /// the whole record's length.
        /// The property can be overriden by subclasses to use different calculation method.</remarks>
        public virtual ushort Length
        {
            get
            {
                ushort length = 0;
                foreach (IField field in fieldList)
                    length += field.Size;
                return length;
            }
        }

        /// <summary>
        /// Returns the <see cref="StdfRecordAttribute"/> of type. <code>type</code> must be a StdfRecord.
        /// </summary>
        /// <param name="type">The type for which the attribute must be retrieved.</param>
        /// <returns>The <see cref="StdfRecordAttribute"/> of type or null if it is not defined.</returns>
        /// <exception cref="ArgumentNullException">If type is null.</exception>
        /// <exception cref="ArgumentException">If type is not a subclass of StdfRecord type.</exception>
        public static StdfRecordAttribute GetStdfRecordAttribute(Type type)
        {
            Debug.Assert(type != null && type.IsSubclassOf(typeof(StdfRecord)));
            if (type == null)
                throw new ArgumentNullException("type", Resources.ObjectCannotBeNull);
            if (!(type.IsSubclassOf(typeof(StdfRecord))))
                throw new ArgumentException(Resources.TypeMustBeStdfRecord, "type");
            
            return Attribute.GetCustomAttribute(type, typeof(StdfRecordAttribute)) as StdfRecordAttribute;
        }
    }
}